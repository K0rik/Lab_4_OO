﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp10
{
    class Program
    {
        class MAtrix
        {
            int[,] a;
            int n, m;
            int count = 0;
            Random r = new Random();
            public MAtrix(int n=3,int m=3)
            {
                this.n = n;
                this.m = m;
                a = new int[n, m];
            }
            public void Fill_Matrix()
            {
                for (int i = 0; i < n; ++i)
                    for (int j = 0; j < m; ++j)
                        a[i, j] = r.Next(0, 4);
            }
            public void Show_Matrix()
            {
               for(int i = 0; i < n; ++i)
                {
                    for (int j = 0; j < m; ++j)
                        Console.Write(a[i, j] + "  ");
                    Console.WriteLine();
                }
            }

            public void Count_Matrix()
            {
                count = 0;
                for (int i = 0; i < n-1; ++i)
                {
                    for (int j = 0; j < m-1; ++j)
                        if(a[i,j]!=a[i+1,j] && a[i, j] != a[i,j+1] && a[i, j] != a[i+1, j + 1] && a[i+1, j] != a[i, j + 1] && a[i+1, j] != a[i+1, j + 1] && a[i, j+1] != a[i+1, j + 1])
                        {
                            ++count;
                        }
                }
                Console.WriteLine(count);
            }
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Введiть к-сть рядкiв : ");
            int n = int.Parse(Console.ReadLine());
            Console.WriteLine("Введiть к-сть стовпцiв : ");
            int m = int.Parse(Console.ReadLine());
            MAtrix mat = new MAtrix(n, m);
            mat.Fill_Matrix();
            mat.Show_Matrix();
            mat.Count_Matrix();
        }
    }
}
